using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bird : MonoBehaviour
{
    public bool isBird1 = false;
    public bool isBird2 = false;

   
    private void OnBecameInvisible() { Destroy(gameObject); }
    // Start is called before the first frame update
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Player")
        {
            Destroy(gameObject);
        }
        if (collision.collider.tag == "RightWall" && isBird2)
        {
            Destroy(gameObject);
        }
        if(collision.collider.tag=="LeftWall" && isBird1)
        {
            Destroy(gameObject);
        }
        if (collision.collider.name == "Bag1Prefab(Clone)" ||
            collision.collider.name == "Bag2Prefab(Clone)" ||
            collision.collider.name == "Bag3Prefab(Clone)")
        {
            Destroy(gameObject);
        }
    }
}
