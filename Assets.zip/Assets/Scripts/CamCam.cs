using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamCam : MonoBehaviour
{
    public Vector3 newCamPos;
    private GameObject cam;

    void Start()
    {
        cam = GameObject.FindGameObjectWithTag("MainCamera");
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            cam.transform.position = newCamPos;   
        }
    }

}