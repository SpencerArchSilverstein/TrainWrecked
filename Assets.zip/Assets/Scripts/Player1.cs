using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player1 : MonoBehaviour
{

    public bool isLeft;
    public bool isRight;

    public bool isJumping;
    public bool isTouchingGround;
    public bool canThePlayerJump;

    public float jumpForce = 5f;

    private Rigidbody2D playerRigidBody;
    private SpriteRenderer playerSpriteRenderer;

    public string dirLog;

    private Animator myAnimator;
    public bool isRunning;

    public float runForce = 2f;

    public GameObject baggSpawner1;
    public GameObject baggSpawner2;

    AudioSource jumpSource;
    AudioSource fallSource;
    AudioSource respawnSource;
    AudioSource nextLevelSource;
    AudioSource collisionSource;


    // Start is called before the first frame update
    void Start()
    {
        isTouchingGround = true;
        canThePlayerJump = true;
        playerRigidBody = GetComponent<Rigidbody2D>();
        var myAudio = FindObjectsOfType<AudioSource>();


        playerSpriteRenderer = GetComponent<SpriteRenderer>();
        myAnimator = GetComponent<Animator>();
        var respawnPos = new Vector2(2.585f, -1.597f);
        gameObject.transform.position = respawnPos;
        jumpSource = myAudio[3];
        jumpSource.volume = 0.5f;
        fallSource = myAudio[4];
        fallSource.volume = 0.5f;
        respawnSource = myAudio[1];
        respawnSource.volume = 0.5f;
        nextLevelSource = myAudio[2];
        nextLevelSource.volume = 0.5f;
        collisionSource = myAudio[0];
        collisionSource.volume = 0.5f;


    }
    private void OnCollisionEnter2D(Collision2D collision)
    { 
        if (collision.collider.tag == "Platform")
        {
            isTouchingGround = true;    
        }
        if (collision.collider.tag == "OOBFloor")
        {
            fallSource.Play();
            var respawnPos = new Vector2(2.585f, -1.597f);
            gameObject.transform.position = respawnPos;
            Invoke("playTheRespawnSource", 0.5f);
        }
        if (collision.collider.tag == "OOBCieling1")
        {
            nextLevelSource.Play();
            float oldX = gameObject.transform.position.x;
            var L2Pos = new Vector2(oldX + 6.5f, -1.99566f);
            gameObject.transform.position = L2Pos;
            var spawnVector = new Vector2(75f, jumpForce * 1.05f);
            playerRigidBody.AddForce(spawnVector);
            var newBS1Vect = new Vector2(baggSpawner1.transform.position.x + 6.718f, baggSpawner2.transform.position.y);
            var newBS2Vect = new Vector2(baggSpawner2.transform.position.x + 6.718f, baggSpawner2.transform.position.y);
            baggSpawner1.transform.position = newBS1Vect;
            baggSpawner2.transform.position = newBS2Vect;
        }
        if (collision.collider.tag == "OOBCieling2")
        {
            float oldX = gameObject.transform.position.x;
            var L2Pos = new Vector2(oldX + 6.5f, -1.99566f);
            gameObject.transform.position = L2Pos;
            var spawnVector = new Vector2(75f, jumpForce * 1.05f);
            playerRigidBody.AddForce(spawnVector);
            var newBS1Vect = new Vector2(baggSpawner1.transform.position.x + 6.823f, baggSpawner2.transform.position.y);
            var newBS2Vect = new Vector2(baggSpawner2.transform.position.x + 6.823f, baggSpawner2.transform.position.y);
            baggSpawner1.transform.position = newBS1Vect;
            baggSpawner2.transform.position = newBS2Vect;
        }

        if (collision.collider.tag == "OOBFloor2")
        {
            fallSource.Play();
            var L1Pos = new Vector2(gameObject.transform.position.x - 6.5f, 1.4f);
            gameObject.transform.position = L1Pos;
            var spawnVector = new Vector2(75f, 0f);
            playerRigidBody.AddForce(spawnVector);
            var newBS1Vect = new Vector2(baggSpawner1.transform.position.x - 6.718f, baggSpawner2.transform.position.y);
            var newBS2Vect = new Vector2(baggSpawner2.transform.position.x - 6.718f, baggSpawner2.transform.position.y);
            baggSpawner1.transform.position = newBS1Vect;
            baggSpawner2.transform.position = newBS2Vect;
        }
        if (collision.collider.tag == "OOBFloor3")
        {
            fallSource.Play();
            float oldX = gameObject.transform.position.x;
            var L3Pos = new Vector2(oldX - 6.5f, 1.4f);
            gameObject.transform.position = L3Pos;
            var spawnVector = new Vector2(75f,0f);
            playerRigidBody.AddForce(spawnVector);
            var newBS1Vect = new Vector2(baggSpawner1.transform.position.x - 6.823f, baggSpawner2.transform.position.y);
            var newBS2Vect = new Vector2(baggSpawner2.transform.position.x - 6.823f, baggSpawner2.transform.position.y);
            baggSpawner1.transform.position = newBS1Vect;
            baggSpawner2.transform.position = newBS2Vect;
        }

        
        if (collision.collider.tag == "OOBCieling3")
        {
            nextLevelSource.Play();
            SceneManager.LoadScene("YouWin 1");
        }
        if (collision.collider.name == "Bag1Prefab(Clone)" ||
            collision.collider.name == "Bag2Prefab(Clone)" ||
            collision.collider.name == "Bag3Prefab(Clone)")
        {
            collisionSource.Play();
            var little_impact = new Vector2(0, -0.5f);
            playerRigidBody.AddForce(little_impact);
            

        }
        if (collision.collider.name == "BlueBirdPrefab(Clone)" ||
            collision.collider.name == "GreenBirdPrefab(Clone)")
        {
            collisionSource.Play();
            var little_impact = new Vector2(-0.5f, 0);
            playerRigidBody.AddForce(little_impact);

        }
    }

    private void playTheRespawnSource()
    {
        respawnSource.Play();
    }
    private void playerMove()
    {
       
        if (Input.GetKey(KeyCode.W) && isTouchingGround && canThePlayerJump)
        {
            jumpSource.Play();
            isTouchingGround = false;
            canThePlayerJump = false;
            var jumpVector = new Vector2(0, jumpForce);
            playerRigidBody.AddForce(jumpVector);
            Invoke("playerJumpHelper", 1f);
        }
        if (Input.GetKey(KeyCode.A))
        {
            if (playerSpriteRenderer.flipX)
            {
                playerSpriteRenderer.flipX = false;
            }
            var runLeftVector = new Vector2(-runForce, 0);
            //if (playerRigidBody.velocity.x > -2f)
            //{
            playerRigidBody.AddForce(runLeftVector);
                //Debug.Log(playerRigidBody.velocity.x);
            //}
        //layerRigidBody.AddForce(runLeftVector);
        }
        if (Input.GetKey(KeyCode.D))
        {
            playerSpriteRenderer.flipX = true;
            var runRightVector = new Vector2(runForce, 0);
            //if (playerRigidBody.velocity.x < 2f)
            //{
            playerRigidBody.AddForce(runRightVector);
                //Debug.Log(playerRigidBody.velocity.x);
            //}
        }
    }

    private void playerJumpHelper() { canThePlayerJump = true; }

    private void canGoBackToMainMenu()
    {
        if (Input.GetKey(KeyCode.Escape))
        {
            SceneManager.LoadScene("Menu");
        }
    }

    private void changeAnimation()
    {
        if (Math.Abs(playerRigidBody.velocity.x) > 0f)
        {
            myAnimator.SetBool("isRunning", true);
        }
        else
        {
            myAnimator.SetBool("isRunning", false);
        }

        if (isTouchingGround)
        {
            myAnimator.SetBool("isTouchingGround", true);
        }
        else
        {
            myAnimator.SetBool("isTouchingGround", false);
        }
    }

    // Update is called once per frame
    void Update()
    {
        playerMove();
        changeAnimation();
        canGoBackToMainMenu();
    }
    void FixedUpdate()
    {
        
    }
}
