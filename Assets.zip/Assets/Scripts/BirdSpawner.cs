using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdSpawner : MonoBehaviour
{
    public GameObject Bird1Prefab;
    private Rigidbody2D rbBird1;
    public float bird1Velocity = 1f;

    public GameObject Bird2Prefab;
    private Rigidbody2D rbBird2;
    public float bird2Velocity = -1f;

    public float birdCounter;
    public float birdCoolDownTime = 4f;

    public bool isSpawner1 = false;
    public bool isSpawner2 = false;
    private void OnBecameInvisible() { Destroy(gameObject); }
    // Start is called before the first frame update
    

    // Start is called before the first frame update
    private void spawnBird()
    {
        if (isSpawner1)
        {
            GameObject birdy1 = Instantiate(Bird1Prefab, transform.position, UnityEngine.Quaternion.identity);
            rbBird1 = birdy1.GetComponent<Rigidbody2D>();
            rbBird1.velocity = transform.right * bird1Velocity;
        }
        if (isSpawner2)
        {
            GameObject birdy2 = Instantiate(Bird2Prefab, transform.position, UnityEngine.Quaternion.identity);
            rbBird2 = birdy2.GetComponent<Rigidbody2D>();
            rbBird2.velocity = transform.right * bird2Velocity;
        }

    }
    void Update()
    {
        if (birdCounter < Time.time)
        {
            spawnBird();
            birdCounter = Time.time + birdCoolDownTime;
        }
    }

}
