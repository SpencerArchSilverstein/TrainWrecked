using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DifficultyTracker : MonoBehaviour
{
    //public static DifficultyTracker Singleton;
    //// Start is called before the first frame update
    //public static void keepTrackOfDifficulty(bool diff)
    //{
    //    Singleton.ChangeDiff(diff);
    //}
    
    //public static bool CallReturnDiff()
    //{
    //    return Singleton.returnDiff();
    //}

    //public bool diffy;

    //void Start()
    //{
    //    Singleton = this;
    //    ChangeDiff(true);
    //}

    //private void ChangeDiff(bool difff)
    //{
    //    diffy = difff;
    //}

    //private bool returnDiff()
    //{
    //    return diffy;
    //}
}
