using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bag : MonoBehaviour
{
    private void OnBecameInvisible() { Destroy(gameObject); }
    // Start is called before the first frame update
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.collider.tag == "Player")
        {
            Destroy(gameObject);
        }
        if(collision.collider.tag == "OOBFloor"
            || collision.collider.tag == "OOBFloor2"
            || collision.collider.tag == "OOBFloor3")
        {
            Destroy(gameObject);
        }
        if(collision.collider.name == "GreenBirdPrefab(Clone)" ||
            collision.collider.name == "BlueBirdPrefab(Clone)")
        {
            Destroy(gameObject);
        }
  
        
    }
}
