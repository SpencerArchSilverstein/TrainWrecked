using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;


public class BagSpawner : MonoBehaviour
{
    public GameObject Bag1Prefab;
    private Rigidbody2D rbBag1;
    public float bag1Velocity = 5f;

    public GameObject Bag2Prefab;
    private Rigidbody2D rbBag2;
    public float bag2Velocity = 5f;

    public GameObject Bag3Prefab;
    private Rigidbody2D rbBag3;
    public float bag3Velocity = 5f;

    public float bagCounter;
    public float bagCoolDownTime = 2f;

    public bool isSpawner1 = false;
    public bool isSpawner2 = false;


    // Start is called before the first frame update
    private void spawnBag()
    {
        int randomInteger = Random.Range(0, 102);
        float randStartFloat = Random.Range(-1f, 1f);
        UnityEngine.Vector3 test = new UnityEngine.Vector3(0, randStartFloat, 0);

        if (randomInteger < 34 && transform.position.y + test.y > 2.25f)
        {
            GameObject baggy1 = Instantiate(Bag1Prefab, transform.position + test, UnityEngine.Quaternion.identity);
            rbBag1 = baggy1.GetComponent<Rigidbody2D>();
            rbBag1.velocity = transform.right * bag1Velocity;
        }
        if(randomInteger >= 34 && randomInteger < 68 && transform.position.y + test.y > 2.25f)
        {
            GameObject baggy2 = Instantiate(Bag2Prefab, transform.position + test, UnityEngine.Quaternion.identity);
            rbBag2 = baggy2.GetComponent<Rigidbody2D>();
            rbBag2.velocity = transform.right * bag2Velocity;
        }
        if (randomInteger >= 68 && randomInteger < 102 && transform.position.y + test.y > 2.25f)
        {
            GameObject baggy3 = Instantiate(Bag3Prefab, transform.position + test, UnityEngine.Quaternion.identity);
            rbBag3 = baggy3.GetComponent<Rigidbody2D>();
            rbBag3.velocity = transform.right * bag3Velocity;
        }
    }

    
    

    // Update is called once per frame
    void Update()
    {
        if (bagCounter < Time.time)
        {
            spawnBag();
            bagCounter = Time.time + bagCoolDownTime;
        }
    }

}
