using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class SceneChanger : MonoBehaviour
{
    public void LoadSceneMenu()
    {
        SceneManager.LoadScene("Menu");
    }
    public void LoadSceneMainHard()
    {
        SceneManager.LoadScene("Main 1");
    }
    public void LoadSceneMainEasy()
    {
        SceneManager.LoadScene("Main");
    }

    public void LoadSceneInstructions()
    {
        SceneManager.LoadScene("Instructions");
    }

}