using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{

    public bool isLeft;
    public bool isRight;

    public bool isJumping;
    public bool isTouchingGround;
    public bool canThePlayerJump;

    public float jumpForce = 5f;

    private Rigidbody2D playerRigidBody;
    private SpriteRenderer playerSpriteRenderer;

    public string dirLog;

    private Animator myAnimator;
    public bool isRunning;

    public float runForce = 2f;

    public GameObject baggSpawner1;
    public GameObject baggSpawner2;

    AudioSource jumpSource;
    AudioSource fallSource;
    AudioSource respawnSource;
    AudioSource nextLevelSource;
    AudioSource collisionSource;



    // Start is called before the first frame update
    void Start()
    {
        isTouchingGround = true;
        canThePlayerJump = true;
        playerRigidBody = GetComponent<Rigidbody2D>();
          

        playerSpriteRenderer = GetComponent<SpriteRenderer>();
        myAnimator = GetComponent<Animator>();
        var respawnPos = new Vector2(2.585f, -1.597f);
        gameObject.transform.position = respawnPos;

        var myAudio = FindObjectsOfType<AudioSource>();
        jumpSource = myAudio[3];
        jumpSource.volume = 0.5f;
        fallSource = myAudio[2];
        fallSource.volume = 0.5f;
        respawnSource = myAudio[0];
        respawnSource.volume = 0.5f;
        nextLevelSource = myAudio[1];
        nextLevelSource.volume = 0.5f;
        collisionSource = myAudio[4];
        collisionSource.volume = 0.5f;

    }
    private void OnCollisionEnter2D(Collision2D collision)
    { 
        if (collision.collider.tag == "Platform")
        {
            isTouchingGround = true;    
        }
        if (collision.collider.tag == "OOBFloor")
        {
            
            fallSource.Play();
            Invoke("playTheRespawnSource", 0.5f);
            var respawnPos = new Vector2(2.585f, -1.597f);
            gameObject.transform.position = respawnPos;
            
        }
        if (collision.collider.tag == "OOBCieling1")
        {
            nextLevelSource.Play();
            float oldX = gameObject.transform.position.x;
            var L2Pos = new Vector2(oldX + 6.5f, -1.99566f);
            gameObject.transform.position = L2Pos;
            var spawnVector = new Vector2(75f, jumpForce * 1.05f);
            playerRigidBody.AddForce(spawnVector);
            var newBS1Vect = new Vector2(baggSpawner1.transform.position.x + 6.718f, baggSpawner2.transform.position.y);
            var newBS2Vect = new Vector2(baggSpawner2.transform.position.x + 6.718f, baggSpawner2.transform.position.y);
            baggSpawner1.transform.position = newBS1Vect;
            baggSpawner2.transform.position = newBS2Vect;
            
        }
        if (collision.collider.tag == "OOBCieling2")
        {
            nextLevelSource.Play();
            float oldX = gameObject.transform.position.x;
            var L2Pos = new Vector2(oldX + 6.5f, -1.99566f);
            gameObject.transform.position = L2Pos;
            var spawnVector = new Vector2(75f, jumpForce * 1.05f);
            playerRigidBody.AddForce(spawnVector);
            var newBS1Vect = new Vector2(baggSpawner1.transform.position.x + 6.823f, baggSpawner2.transform.position.y);
            var newBS2Vect = new Vector2(baggSpawner2.transform.position.x + 6.823f, baggSpawner2.transform.position.y);
            baggSpawner1.transform.position = newBS1Vect;
            baggSpawner2.transform.position = newBS2Vect;
        }
        if (collision.collider.tag == "OOBFloor2")
        {
            fallSource.Play(); 
            var respawnPos = new Vector2(5f, -1.5f);
            gameObject.transform.position = respawnPos;
            Invoke("playTheRespawnSource", 0.5f);
            //respawnSource.Play();

        }
        if (collision.collider.tag == "OOBFloor3")
        {
            fallSource.Play();
            var respawnPos = new Vector2(11.872f, -1.578f);
            gameObject.transform.position = respawnPos;
            //respawnSource.Play();
            Invoke("playTheRespawnSource", 0.5f);

        }
        
        
        if (collision.collider.tag == "OOBCieling3")
        {
            nextLevelSource.Play();
            SceneManager.LoadScene("YouWin");
        }
        if (collision.collider.name == "Bag1Prefab(Clone)" ||
            collision.collider.name == "Bag2Prefab(Clone)" ||
            collision.collider.name == "Bag3Prefab(Clone)")
        {
            var little_impact = new Vector2(0, -1.2f);
            playerRigidBody.AddForce(little_impact);
            collisionSource.Play();

        }
        if (collision.collider.name == "BlueBirdPrefab(Clone)" ||
            collision.collider.name == "GreenBirdPrefab(Clone)")
        {
            var little_impact = new Vector2(-1.2f, 0);
            playerRigidBody.AddForce(little_impact);
            collisionSource.Play();

        }
    }
    //var platformBoxColl = collision.collider.GetComponent<BoxCollider2D>();
    //        if(platformBoxColl.transform.position.y<transform.position.y)
    //        {
    private void playTheRespawnSource()
    {
        respawnSource.Play();
    }
    private void playerMove()
    {
       
        if (Input.GetKey(KeyCode.W) && isTouchingGround && canThePlayerJump)
        {
            isTouchingGround = false;
            canThePlayerJump = false;
            jumpSource.Play();
            var jumpVector = new Vector2(0, jumpForce);
            playerRigidBody.AddForce(jumpVector);
            Invoke("playerJumpHelper", 1f);
        }
        if (Input.GetKey(KeyCode.A))
        {
            if (playerSpriteRenderer.flipX)
            {
                playerSpriteRenderer.flipX = false;
            }
            var runLeftVector = new Vector2(-runForce, 0);
            playerRigidBody.AddForce(runLeftVector);
        }
        if (Input.GetKey(KeyCode.D))
        {
            playerSpriteRenderer.flipX = true;
            var runRightVector = new Vector2(runForce, 0);
            playerRigidBody.AddForce(runRightVector);
        }
    }

    private void playerJumpHelper() { canThePlayerJump = true; }

    private void canGoBackToMainMenu()
    {
        if (Input.GetKey(KeyCode.Escape))
        {
            SceneManager.LoadScene("Menu");
        }
    }

    private void changeAnimation()
    {
        if (Math.Abs(playerRigidBody.velocity.x) > 0f)
        {
            myAnimator.SetBool("isRunning", true);
        }
        else
        {
            myAnimator.SetBool("isRunning", false);
        }

        if (isTouchingGround)
        {
            myAnimator.SetBool("isTouchingGround", true);
        }
        else
        {
            myAnimator.SetBool("isTouchingGround", false);
        }
    }

    // Update is called once per frame
    void Update()
    {
        playerMove();
        changeAnimation();
        canGoBackToMainMenu();
    }
    void FixedUpdate()
    {
        
    }
}
